package redVendedores.model;

public enum TipoEstado {
	VENDIDO, PUBLICADO, CANCELADO;
}

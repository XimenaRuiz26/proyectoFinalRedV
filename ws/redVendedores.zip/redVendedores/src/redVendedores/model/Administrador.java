package redVendedores.model;

public class Administrador extends Usuario{

	public Administrador(String nombre, String apellido, String cedula, String direccion, RedV redV) {
		super(nombre, apellido, cedula, direccion, redV);
	}
}

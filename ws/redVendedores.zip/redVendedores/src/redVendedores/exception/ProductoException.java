package redVendedores.exception;

public class ProductoException extends Exception{
	public ProductoException(String mensaje){
		super(mensaje);
	}

}

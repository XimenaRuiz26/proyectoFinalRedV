package redVendedores.exception;

public class AdministradorException extends Exception {
	public AdministradorException(String mensaje){
		super(mensaje);
	}

}

package redVendedores.exception;

public class VendedorException extends Exception{

	public VendedorException(String mensaje){
		super(mensaje);
	}
}
